package com.apple.greenapple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenAppleApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreenAppleApplication.class, args);
	}

}

package com.apple.greenapple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenAppleApplicationTests {

	@Test
	void contextLoads() {
	}

}
